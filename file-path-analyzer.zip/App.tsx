
import React, { useState, useCallback } from 'react';
import { analyzeFilePath } from './services/geminiService';
import Header from './components/Header';
import FileInput from './components/FileInput';
import ResultCard from './components/ResultCard';
import Loader from './components/Loader';
import { FileCode, AlertTriangle } from './components/IconComponents';

const App: React.FC = () => {
  const initialPath = '/data/data/com.offsec.nhterm/files/usr/bin/kali/data/data/com.offsec.nhterm/files/usr/bin/kali';
  const [filePath, setFilePath] = useState<string>(initialPath);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = useCallback(async () => {
    if (!filePath.trim()) {
      setError('File path cannot be empty.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysis(null);

    try {
      const result = await analyzeFilePath(filePath);
      setAnalysis(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [filePath]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans flex flex-col">
      <Header />
      <main className="flex-grow flex flex-col items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-4xl space-y-8">
          <div className="text-center">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-cyan-400">
              AI-Powered File Path Analyzer
            </h2>
            <p className="mt-2 text-lg text-gray-400">
              Enter a file path to get a detailed breakdown from Gemini.
            </p>
          </div>
          
          <FileInput 
            filePath={filePath}
            setFilePath={setFilePath}
            onAnalyze={handleAnalyze}
            isLoading={isLoading}
          />

          <div className="mt-8 min-h-[300px] w-full">
            {isLoading && <Loader />}
            {error && (
              <div className="bg-red-900/50 border border-red-500 text-red-300 px-4 py-3 rounded-lg relative flex items-center gap-3">
                <AlertTriangle className="h-6 w-6" />
                <span className="font-medium">{error}</span>
              </div>
            )}
            {analysis && <ResultCard content={analysis} />}
            {!isLoading && !analysis && !error && (
               <div className="flex flex-col items-center justify-center text-center p-8 bg-gray-800/50 border-2 border-dashed border-gray-600 rounded-lg h-full">
                <FileCode className="h-16 w-16 text-gray-500 mb-4" />
                <h3 className="text-xl font-semibold text-gray-300">Awaiting Analysis</h3>
                <p className="text-gray-400 mt-1">
                  Your detailed path analysis will appear here.
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
      <footer className="text-center p-4 text-gray-500 text-sm">
        <p>&copy; {new Date().getFullYear()} File Path Analyzer. Powered by Google Gemini.</p>
      </footer>
    </div>
  );
};

export default App;
