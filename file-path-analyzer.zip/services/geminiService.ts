
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This case should be handled by the environment, but it's good practice to check.
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export async function analyzeFilePath(path: string): Promise<string> {
  const prompt = `
    As a senior cybersecurity and operating systems expert, analyze the following file path: "${path}".

    Provide a detailed breakdown covering:
    1.  **Probable Operating System:** Identify the OS this path most likely belongs to (e.g., Linux, Windows, macOS, Android, iOS). Explain your reasoning.
    2.  **Path Decomposition:** Break down the path segment by segment (e.g., /data, /com.offsec.nhterm) and explain the typical purpose and context of each directory.
    3.  **Context and Significance:** Based on the components, what is the likely context of this path? What application or tool does it relate to? What is its overall significance from a technical or security perspective?
    4.  **Interesting Observations:** Note any unusual patterns, repetitions, non-standard directory names, or specific names that stand out.

    Present your analysis in a clear, well-structured format. Use Markdown for formatting, including headers, bold text, and lists.
  `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
    });

    const text = response.text;
    if (!text) {
        throw new Error('Received an empty response from the API.');
    }
    return text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
            throw new Error('The configured API key is invalid. Please check your credentials.');
        }
         throw new Error(`Failed to analyze path: ${error.message}`);
    }
    throw new Error("An unknown error occurred while communicating with the Gemini API.");
  }
}
