
import React from 'react';
import { marked } from 'marked';

interface ResultCardProps {
  content: string;
}

const ResultCard: React.FC<ResultCardProps> = ({ content }) => {
  const parsedContent = marked.parse(content);

  return (
    <div className="bg-gray-800/50 border border-gray-700 rounded-lg shadow-lg shadow-cyan-500/10 p-6 animate-fade-in">
      <div className="prose prose-invert prose-sm sm:prose-base max-w-none 
        prose-headings:text-cyan-400 prose-h1:text-2xl prose-h2:text-xl prose-h3:text-lg 
        prose-strong:text-gray-100 
        prose-a:text-cyan-400 hover:prose-a:text-cyan-300
        prose-code:bg-gray-900 prose-code:p-1 prose-code:rounded-md prose-code:text-sm prose-code:font-mono prose-code:text-emerald-400
        prose-blockquote:border-l-4 prose-blockquote:border-cyan-500 prose-blockquote:pl-4 prose-blockquote:text-gray-400
        prose-ul:list-disc prose-ul:pl-6
        prose-ol:list-decimal prose-ol:pl-6
      " 
        dangerouslySetInnerHTML={{ __html: parsedContent }} 
      />
    </div>
  );
};

// Simple animation for the card
const styles = `
  @keyframes fade-in {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fade-in {
    animation: fade-in 0.5s ease-out forwards;
  }
`;
const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = styles;
document.head.appendChild(styleSheet);


export default ResultCard;
